import pandas as pd
import streamlit as st
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "data"

st.set_page_config(page_title="Fantasy HQ", layout="wide")
st.title("Fantasy Football HQ — Start/Sit • Trades • Waivers")

col1, col2, col3 = st.columns(3)
with col1:
    st.subheader("Start/Sit (this week)")
    try:
        st.dataframe(pd.read_csv(DATA / "optimal_lineup.csv"))
    except:
        st.write("No data yet. Run workflow.")

with col2:
    st.subheader("Trade Values (ROS)")
    try:
        st.dataframe(pd.read_csv(DATA / "trade_values.csv").head(50))
    except:
        st.write("No data yet. Run workflow.")

with col3:
    st.subheader("Top Waivers")
    try:
        st.dataframe(pd.read_csv(DATA / "waiver_priority.csv").head(25))
    except:
        st.write("No data yet. Run workflow.")

st.caption("Auto-updating daily via GitHub Actions. Scoring & league set via repo secrets.")
