import pathlib, pandas as pd

BASE = pathlib.Path(__file__).resolve().parents[1]
DATA = BASE / "data"

def main():
    proj = pd.read_csv(DATA / "projections_weekly.csv")
    ros = proj.groupby(["player_id","player_name","position"])["proj_points"].sum().reset_index()
    ranks = ros.groupby("position")["proj_points"].rank(ascending=False, method="first")
    ros["rank"] = ranks
    repl = ros.groupby("position")["proj_points"].quantile(0.75)
    ros["value_over_replacement"] = ros.apply(lambda r: r["proj_points"] - repl[r["position"]], axis=1)
    ros.sort_values("value_over_replacement", ascending=False).to_csv(DATA / "trade_values.csv", index=False)

if __name__ == "__main__":
    main()
