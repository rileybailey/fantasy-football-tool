import pathlib, pandas as pd

BASE = pathlib.Path(__file__).resolve().parents[1]
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)

def main():
    url = "https://raw.githubusercontent.com/nflverse/nflfastR-data/master/data/player_stats/player_stats_2025.csv.gz"
    df = pd.read_csv(url, compression="gzip")
    df.to_csv(DATA / "nflfastr_player_stats_2025.csv", index=False)

if __name__ == "__main__":
    main()
