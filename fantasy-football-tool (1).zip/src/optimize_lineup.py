import pandas as pd, pathlib

BASE = pathlib.Path(__file__).resolve().parents[1]
DATA = BASE / "data"

LINEUP = ["QB","RB","RB","WR","WR","TE","FLEX","FLEX","DST","K"]

def main():
    proj = pd.read_csv(DATA / "projections_weekly.csv")
    roster_file = DATA / "my_roster.csv"
    if not roster_file.exists():
        return
    roster = pd.read_csv(roster_file)
    merged = roster.merge(proj, on="player_id", how="left").fillna(0)
    starters, used = [], set()

    def pick(pos_list):
        pool = merged[merged["position"].isin(pos_list)]
        pool = pool[~pool["player_id"].isin(used)].sort_values("proj_points", ascending=False)
        return pool.iloc[0] if len(pool) else None

    for slot in LINEUP:
        row = pick(["RB","WR","TE"]) if slot=="FLEX" else pick([slot])
        if row is None: continue
        used.add(row.player_id)
        starters.append({"slot": slot, "name": row.player_name, "proj": row.proj_points})

    pd.DataFrame(starters).to_csv(DATA / "optimal_lineup.csv", index=False)

if __name__ == "__main__":
    main()
