import pathlib, pandas as pd

BASE = pathlib.Path(__file__).resolve().parents[1]
DATA = BASE / "data"

def main():
    fa_file = DATA / "free_agents.csv"
    if not fa_file.exists():
        return
    fa = pd.read_csv(fa_file)
    proj = pd.read_csv(DATA / "projections_weekly.csv")
    recent = proj.sort_values("week").groupby("player_id").tail(1)[["player_id","proj_points"]]
    ranked = fa.merge(recent, on="player_id", how="left").fillna({"proj_points":0})
    ranked["priority"] = ranked["proj_points"]
    ranked.sort_values("priority", ascending=False).to_csv(DATA / "waiver_priority.csv", index=False)

if __name__ == "__main__":
    main()
