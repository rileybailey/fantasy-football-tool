import json, os, pathlib, pandas as pd

BASE = pathlib.Path(__file__).resolve().parents[1]
DATA = BASE / "data"

SCORING = json.loads(os.environ["SCORING_JSON"])

def fantasy_points(row):
    pts = 0.0
    pts += SCORING.get("pass_yd",0)*row.get("passing_yards",0)
    pts += SCORING.get("pass_td",0)*row.get("passing_tds",0)
    pts += SCORING.get("rush_yd",0)*row.get("rushing_yards",0)
    pts += SCORING.get("rush_td",0)*row.get("rushing_tds",0)
    pts += SCORING.get("rec",0)*row.get("receptions",0)
    pts += SCORING.get("rec_yd",0)*row.get("receiving_yards",0)
    pts += SCORING.get("rec_td",0)*row.get("receiving_tds",0)
    pts += SCORING.get("int",0)*row.get("interceptions",0)
    pts += SCORING.get("fumble",0)*row.get("fumbles_lost",0)
    return pts

def main():
    stats = pd.read_csv(DATA / "nflfastr_player_stats_2025.csv")
    stats = stats.sort_values(["player_id","week"])
    rolling = stats.groupby("player_id").rolling(3, on="week").mean(numeric_only=True).reset_index()
    proj = rolling.rename(columns={"fantasy_points_ppr":"fp_rolling"}).fillna(0)
    proj["proj_points"] = proj["fp_rolling"].clip(lower=0)
    out = proj[["player_id","player_name","position","team","week","proj_points"]]
    out.to_csv(DATA / "projections_weekly.csv", index=False)

if __name__ == "__main__":
    main()
