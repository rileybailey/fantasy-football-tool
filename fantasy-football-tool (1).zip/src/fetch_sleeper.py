import os, json, requests, pathlib

BASE = pathlib.Path(__file__).resolve().parents[1]
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)

LEAGUE_ID = os.environ["SLEEPER_LEAGUE_ID"]

def get(url):
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    return r.json()

def main():
    league = get(f"https://api.sleeper.app/v1/league/{LEAGUE_ID}")
    rosters = get(f"https://api.sleeper.app/v1/league/{LEAGUE_ID}/rosters")
    users = get(f"https://api.sleeper.app/v1/league/{LEAGUE_ID}/users")
    trending_adds = get("https://api.sleeper.app/v1/players/nfl/trending/add?limit=200")
    trending_drops = get("https://api.sleeper.app/v1/players/nfl/trending/drop?limit=200")
    players_meta = get("https://api.sleeper.app/v1/players/nfl")

    for name, obj in [
        ("league.json", league),
        ("rosters.json", rosters),
        ("users.json", users),
        ("trending_adds.json", trending_adds),
        ("trending_drops.json", trending_drops),
        ("players_meta.json", players_meta),
    ]:
        (DATA / name).write_text(json.dumps(obj))

if __name__ == "__main__":
    main()
